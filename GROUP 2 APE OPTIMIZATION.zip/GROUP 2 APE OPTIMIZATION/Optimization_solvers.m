
clear; clc; close all;


% PROBLEM 1: Juice Extraction Optimization (Nonlinear Optimization)

fprintf('====================================================\n');
fprintf('  PROBLEM 1: Juice Extraction Optimization\n');
fprintf('====================================================\n');


fun1 = @(x) (x(1) - 4)^2 + 2*(x(2) - 5)^2;


lb1 = [2, 1];
ub1 = [8, 10];
x0_1 = [3, 3];
nvars1 = 2;


nonlcon1 = @(x) deal(12 - x(1)*x(2), []);


options_fmincon = optimoptions('fmincon', 'Display', 'off');
options_ga1     = optimoptions('ga', 'Display', 'off', 'NonlinearConstraintAlgorithm', 'penalty');
options_ps1     = optimoptions('particleswarm', 'Display', 'off');
options_pat1    = optimoptions('patternsearch', 'Display', 'off');
options_surr1   = optimoptions('surrogateopt', 'Display', 'off', 'MaxFunctionEvaluations', 200);

% 1. fmincon
tic;
[x_fmincon1, f_fmincon1] = fmincon(fun1, x0_1, [], [], [], [], lb1, ub1, nonlcon1, options_fmincon);
t_fmincon1 = toc;

% 2. ga (Genetic Algorithm)
tic;
[x_ga1, f_ga1] = ga(fun1, nvars1, [], [], [], [], lb1, ub1, nonlcon1, options_ga1);
t_ga1 = toc;

% 3. particleswarm 
obj1_ps = @(x) fun1(x) + 1e5 * max(0, 12 - x(1)*x(2))^2;
tic;
[x_ps1, f_ps1_pen] = particleswarm(obj1_ps, nvars1, lb1, ub1, options_ps1);
t_ps1 = toc;
f_ps1 = fun1(x_ps1);

% 4. patternsearch
tic;
[x_pat1, f_pat1] = patternsearch(fun1, x0_1, [], [], [], [], lb1, ub1, nonlcon1, options_pat1);
t_pat1 = toc;

% 5. surrogateopt 
tic;
[x_surr1, f_surr1_pen] = surrogateopt(obj1_ps, lb1, ub1, options_surr1);
t_surr1 = toc;
f_surr1 = fun1(x_surr1);


fprintf('%-15s | %-12s | %-12s | %-12s | %-10s\n', 'Solver', 'x1 (bar)', 'x2 (min)', 'Min f(x)', 'Time (s)');
fprintf('----------------------------------------------------------------------\n');
fprintf('%-15s | %-12.4f | %-12.4f | %-12.6f | %-10.4f\n', 'fmincon', x_fmincon1(1), x_fmincon1(2), f_fmincon1, t_fmincon1);
fprintf('%-15s | %-12.4f | %-12.4f | %-12.6f | %-10.4f\n', 'ga', x_ga1(1), x_ga1(2), f_ga1, t_ga1);
fprintf('%-15s | %-12.4f | %-12.4f | %-12.6f | %-10.4f\n', 'particleswarm', x_ps1(1), x_ps1(2), f_ps1, t_ps1);
fprintf('%-15s | %-12.4f | %-12.4f | %-12.6f | %-10.4f\n', 'patternsearch', x_pat1(1), x_pat1(2), f_pat1, t_pat1);
fprintf('%-15s | %-12.4f | %-12.4f | %-12.6f | %-10.4f\n', 'surrogateopt', x_surr1(1), x_surr1(2), f_surr1, t_surr1);



% PROBLEM 2: Animal Feed Formulation (Linear Programming)

fprintf('\n====================================================\n');
fprintf('  PROBLEM 2: Animal Feed Formulation\n');
fprintf('====================================================\n');


fun2 = @(x) 0.50*x(1) + 0.80*x(2);


Aeq2 = [1, 1]; beq2 = 100;


A2 = [-0.10, -0.30]; b2 = -18;


lb2 = [0, 0];
ub2 = [100, 100];
x0_2 = [50, 50];
nvars2 = 2;


obj2_pen = @(x) fun2(x) + 1e4 * (x(1) + x(2) - 100)^2 + 1e4 * max(0, 18 - 0.10*x(1) - 0.30*x(2))^2;

% 1. fmincon
tic;
[x_fmincon2, f_fmincon2] = fmincon(fun2, x0_2, A2, b2, Aeq2, beq2, lb2, ub2, [], options_fmincon);
t_fmincon2 = toc;

% 2. ga
tic;
[x_ga2, f_ga2] = ga(fun2, nvars2, A2, b2, Aeq2, beq2, lb2, ub2, [], options_ga1);
t_ga2 = toc;

% 3. particleswarm
tic;
[x_ps2, ~] = particleswarm(obj2_pen, nvars2, lb2, ub2, options_ps1);
t_ps2 = toc;
f_ps2 = fun2(x_ps2);

% 4. patternsearch
tic;
[x_pat2, f_pat2] = patternsearch(fun2, x0_2, A2, b2, Aeq2, beq2, lb2, ub2, [], options_pat1);
t_pat2 = toc;

% 5. surrogateopt
tic;
[x_surr2, ~] = surrogateopt(obj2_pen, lb2, ub2, options_surr1);
t_surr2 = toc;
f_surr2 = fun2(x_surr2);


fprintf('%-15s | %-12s | %-12s | %-12s | %-10s\n', 'Solver', 'Maize (kg)', 'Soymeal (kg)', 'Min Cost ($)', 'Time (s)');
fprintf('----------------------------------------------------------------------\n');
fprintf('%-15s | %-12.4f | %-12.4f | %-12.4f | %-10.4f\n', 'fmincon', x_fmincon2(1), x_fmincon2(2), f_fmincon2, t_fmincon2);
fprintf('%-15s | %-12.4f | %-12.4f | %-12.4f | %-10.4f\n', 'ga', x_ga2(1), x_ga2(2), f_ga2, t_ga2);
fprintf('%-15s | %-12.4f | %-12.4f | %-12.4f | %-10.4f\n', 'particleswarm', x_ps2(1), x_ps2(2), f_ps2, t_ps2);
fprintf('%-15s | %-12.4f | %-12.4f | %-12.4f | %-10.4f\n', 'patternsearch', x_pat2(1), x_pat2(2), f_pat2, t_pat2);
fprintf('%-15s | %-12.4f | %-12.4f | %-12.4f | %-10.4f\n', 'surrogateopt', x_surr2(1), x_surr2(2), f_surr2, t_surr2);



% PROBLEM 3: Cold Storage Selection (Mixed-Integer Linear Programming)

fprintf('\n====================================================\n');
fprintf('  PROBLEM 3: Cold Storage Warehouse Selection\n');
fprintf('====================================================\n');


fun3 = @(x) 300*x(1) + 450*x(2) + 700*x(3);


A3 = [-20, -30, -60]; b3 = -50;

lb3 = [0, 0, 0];
ub3 = [1, 1, 1];
x0_3 = [0.5, 0.5, 0.5];
nvars3 = 3;
intcon3 = [1, 2, 3];


obj3_pen = @(x) fun3(round(x)) + 1e5 * max(0, 50 - 20*round(x(1)) - 30*round(x(2)) - 60*round(x(3)));

% 1. fmincon 
tic;
[x_fmincon3_raw, ~] = fmincon(fun3, x0_3, A3, b3, [], [], lb3, ub3, [], options_fmincon);
t_fmincon3 = toc;
x_fmincon3 = round(x_fmincon3_raw);
f_fmincon3 = fun3(x_fmincon3);

% 2. ga 
tic;
[x_ga3, f_ga3] = ga(fun3, nvars3, A3, b3, [], [], lb3, ub3, [], intcon3, options_ga1);
t_ga3 = toc;

% 3. particleswarm
tic;
[x_ps3_raw, ~] = particleswarm(obj3_pen, nvars3, lb3, ub3, options_ps1);
t_ps3 = toc;
x_ps3 = round(x_ps3_raw);
f_ps3 = fun3(x_ps3);

% 4. patternsearch
tic;
[x_pat3_raw, ~] = patternsearch(fun3, x0_3, A3, b3, [], [], lb3, ub3, [], options_pat1);
t_pat3 = toc;
x_pat3 = round(x_pat3_raw);
f_pat3 = fun3(x_pat3);

% 5. surrogateopt 
tic;
[x_surr3, f_surr3] = surrogateopt(fun3, lb3, ub3, intcon3, A3, b3, [], [], options_surr1);
t_surr3 = toc;

fprintf('%-15s | %-10s | %-10s | %-10s | %-12s | %-10s\n', 'Solver', 'x1', 'x2', 'x3', 'Min Overhead', 'Time (s)');
fprintf('------------------------------------------------------------------------------\n');
fprintf('%-15s | %-10d | %-10d | %-10d | %-12.2f | %-10.4f\n', 'fmincon', x_fmincon3(1), x_fmincon3(2), x_fmincon3(3), f_fmincon3, t_fmincon3);
fprintf('%-15s | %-10d | %-10d | %-10d | %-12.2f | %-10.4f\n', 'ga', x_ga3(1), x_ga3(2), x_ga3(3), f_ga3, t_ga3);
fprintf('%-15s | %-10d | %-10d | %-10d | %-12.2f | %-10.4f\n', 'particleswarm', x_ps3(1), x_ps3(2), x_ps3(3), f_ps3, t_ps3);
fprintf('%-15s | %-10d | %-10d | %-10d | %-12.2f | %-10.4f\n', 'patternsearch', x_pat3(1), x_pat3(2), x_pat3(3), f_pat3, t_pat3);
fprintf('%-15s | %-10d | %-10d | %-10d | %-12.2f | %-10.4f\n', 'surrogateopt', x_surr3(1), x_surr3(2), x_surr3(3), f_surr3, t_surr3);



solvers = {'fmincon', 'ga', 'particleswarm', 'patternsearch', 'surrogateopt'};
times = [
    t_fmincon1, t_ga1, t_ps1, t_pat1, t_surr1;
    t_fmincon2, t_ga2, t_ps2, t_pat2, t_surr2;
    t_fmincon3, t_ga3, t_ps3, t_pat3, t_surr3
]';

figure('Name', 'Optimization Solvers Execution Time Benchmark', 'NumberTitle', 'off', 'Position', [100, 100, 1000, 500]);
b = bar(times, 'grouped');
grid on;
set(gca, 'XTickLabel', solvers, 'FontSize', 11);
ylabel('Execution Time (seconds)', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('Optimization Solver', 'FontSize', 12, 'FontWeight', 'bold');
title('Execution Time Comparison across Problems 1-3', 'FontSize', 14);
legend({'Problem 1: Juice Extraction', 'Problem 2: Feed Formulation', 'Problem 3: Warehouse Selection'}, ...
       'Location', 'northwest', 'FontSize', 10);
colormap(lines(3));


for i = 1:size(times, 2)
    xpos = b(i).XEndPoints;
    ypos = b(i).YEndPoints;
    labels = string(num2str(ypos', '%.3fs'));
    text(xpos, ypos, labels, 'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', 'FontSize', 8);
end